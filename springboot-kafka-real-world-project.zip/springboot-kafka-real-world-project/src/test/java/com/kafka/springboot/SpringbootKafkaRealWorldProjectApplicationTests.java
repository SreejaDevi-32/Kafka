package com.kafka.springboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootKafkaRealWorldProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
